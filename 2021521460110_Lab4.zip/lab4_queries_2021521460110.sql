
-- PART 1: CREATE DATABASE SCHEMA WITH INTEGRITY CONSTRAINTS

-- Create database
CREATE DATABASE IF NOT EXISTS customer_orders_db;
USE customer_orders_db;

-- Create tables with integrity constraints
CREATE TABLE customers (
    customer_id INT AUTO_INCREMENT PRIMARY KEY,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    email VARCHAR(100) UNIQUE,  -- INTEGRITY CONSTRAINT 1: UNIQUE
    phone VARCHAR(20),
    date_of_birth DATE,
    ssn VARCHAR(11),            -- Sensitive data we'll hide in view
    credit_limit DECIMAL(10,2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE products (
    product_id INT AUTO_INCREMENT PRIMARY KEY,
    product_name VARCHAR(100) NOT NULL,
    category VARCHAR(50),
    price DECIMAL(10,2) NOT NULL CHECK (price > 0),  -- INTEGRITY CONSTRAINT 2: CHECK
    stock_quantity INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE orders (
    order_id INT AUTO_INCREMENT PRIMARY KEY,
    customer_id INT,
    order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status VARCHAR(20) DEFAULT 'Pending',
    total_amount DECIMAL(10,2),
    shipping_address VARCHAR(255),
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id) ON DELETE CASCADE  -- INTEGRITY CONSTRAINT 3: FOREIGN KEY
);

CREATE TABLE order_items (
    item_id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT,
    product_id INT,
    quantity INT NOT NULL,
    price_per_unit DECIMAL(10,2),
    FOREIGN KEY (order_id) REFERENCES orders(order_id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(product_id)
);

-- PART 2: CREATE VIEW TO HIDE SENSITIVE DATA

CREATE VIEW customer_safe_view AS
SELECT 
    customer_id,
    first_name,
    last_name,
    email,
    phone,
    created_at
FROM customers;


-- PART 3: CREATE INDEX ON COMMONLY USED COLUMNS

-- Create index on customer_id in orders table (commonly used in JOINs)
CREATE INDEX idx_orders_customer_id ON orders(customer_id);

-- Create index on product search (commonly used in WHERE conditions)
CREATE INDEX idx_product_name ON products(product_name);


-- PART 4: INSERT SAMPLE DATA


-- Insert sample customers
INSERT INTO customers (first_name, last_name, email, phone, date_of_birth, ssn, credit_limit)
VALUES 
('John', 'Smith', 'john.smith@email.com', '555-123-4567', '1985-06-15', '123-45-6789', 5000.00),
('Emily', 'Johnson', 'emily.j@email.com', '555-234-5678', '1990-09-22', '234-56-7890', 3500.00),
('Michael', 'Brown', 'michael.b@email.com', '555-345-6789', '1978-03-10', '345-67-8901', 7500.00),
('Sarah', 'Davis', 'sarah.d@email.com', '555-456-7890', '1992-11-30', '456-78-9012', 2000.00),
('David', 'Wilson', 'david.w@email.com', '555-567-8901', '1982-08-05', '567-89-0123', 4500.00);

-- Insert sample products
INSERT INTO products (product_name, category, price, stock_quantity)
VALUES 
('Smartphone X', 'Electronics', 899.99, 50),
('Laptop Pro', 'Electronics', 1299.99, 30),
('Wireless Headphones', 'Electronics', 149.99, 100),
('Coffee Maker Deluxe', 'Kitchen', 79.99, 45),
('Running Shoes', 'Footwear', 129.99, 75),
('Designer Watch', 'Accessories', 249.99, 25),
('Fitness Tracker', 'Electronics', 89.99, 60),
('Portable Speaker', 'Electronics', 69.99, 80);

-- Insert sample orders
INSERT INTO orders (customer_id, order_date, status, total_amount, shipping_address)
VALUES 
(1, '2024-03-01 10:30:00', 'Delivered', 949.98, '123 Main St, Anytown, USA'),
(2, '2024-03-05 14:45:00', 'Shipped', 1299.99, '456 Oak Ave, Somewhere, USA'),
(3, '2024-03-10 09:15:00', 'Processing', 339.97, '789 Pine Rd, Nowhere, USA'),
(4, '2024-03-15 16:20:00', 'Pending', 129.99, '321 Elm St, Anywhere, USA'),
(5, '2024-03-20 11:50:00', 'Delivered', 159.98, '654 Cedar Ln, Everywhere, USA'),
(1, '2024-03-25 13:25:00', 'Shipped', 249.99, '123 Main St, Anytown, USA');

-- Insert sample order items
INSERT INTO order_items (order_id, product_id, quantity, price_per_unit)
VALUES 
(1, 1, 1, 899.99),
(1, 3, 1, 49.99),
(2, 2, 1, 1299.99),
(3, 3, 1, 149.99),
(3, 4, 1, 79.99),
(3, 7, 1, 89.99),
(4, 5, 1, 129.99),
(5, 7, 1, 89.99),
(5, 8, 1, 69.99),
(6, 6, 1, 249.99);


-- PART 5: DEMONSTRATE TRANSACTION

-- Start a transaction
START TRANSACTION;

-- Insert a new order
INSERT INTO orders (customer_id, status, total_amount, shipping_address)
VALUES (3, 'Pending', 219.98, '789 Pine Rd, Nowhere, USA');

-- Get the new order ID
SET @new_order_id = LAST_INSERT_ID();

-- Insert order items
INSERT INTO order_items (order_id, product_id, quantity, price_per_unit)
VALUES 
(@new_order_id, 8, 2, 69.99),
(@new_order_id, 7, 1, 89.99);

-- Update stock quantity
UPDATE products SET stock_quantity = stock_quantity - 2 WHERE product_id = 8;
UPDATE products SET stock_quantity = stock_quantity - 1 WHERE product_id = 7;

-- Show data before commit (this will only be visible in the current session)
SELECT * FROM orders WHERE order_id = @new_order_id;
SELECT * FROM order_items WHERE order_id = @new_order_id;
SELECT product_id, stock_quantity FROM products WHERE product_id IN (7, 8);

-- Commit the transaction
COMMIT;

-- Show data after commit (this will be visible to all sessions)
SELECT * FROM orders WHERE order_id = @new_order_id;
SELECT * FROM order_items WHERE order_id = @new_order_id;
SELECT product_id, product_name, stock_quantity FROM products WHERE product_id IN (7, 8);


-- PART 6: COMPLEX QUERY


-- Complex query with JOIN, SUBQUERY, and WHERE/HAVING conditions
SELECT 
    c.customer_id,
    CONCAT(c.first_name, ' ', c.last_name) AS customer_name,
    COUNT(o.order_id) AS total_orders,
    SUM(o.total_amount) AS total_spent,
    AVG(o.total_amount) AS average_order_value,
    (SELECT MAX(order_date) FROM orders WHERE customer_id = c.customer_id) AS last_order_date,
    (SELECT product_name FROM products p 
     JOIN order_items oi ON p.product_id = oi.product_id
     JOIN orders o2 ON oi.order_id = o2.order_id
     WHERE o2.customer_id = c.customer_id
     GROUP BY p.product_id
     ORDER BY COUNT(oi.item_id) DESC
     LIMIT 1) AS most_purchased_product
FROM 
    customers c
JOIN 
    orders o ON c.customer_id = o.customer_id
GROUP BY 
    c.customer_id
HAVING 
    total_orders > 1
ORDER BY 
    total_spent DESC;


-- PART 7: CREATE ROLE AND GRANT PRIVILEGES (BONUS)


-- Create a read-only analyst role
CREATE ROLE IF NOT EXISTS 'analyst';

-- Grant SELECT privileges on the safe view and other tables
GRANT SELECT ON customer_orders_db.customer_safe_view TO 'analyst';
GRANT SELECT ON customer_orders_db.products TO 'analyst';
GRANT SELECT ON customer_orders_db.orders TO 'analyst';
GRANT SELECT ON customer_orders_db.order_items TO 'analyst';

-- Create a user and assign the role (you would use a secure password in production)
CREATE USER IF NOT EXISTS 'data_analyst'@'localhost' IDENTIFIED BY 'securepassword';
GRANT 'analyst' TO 'data_analyst'@'localhost';


-- ADDITIONAL QUERIES TO VERIFY REQUIREMENTS


-- Check view (should not display sensitive SSN or credit_limit)
SELECT * FROM customer_safe_view;

-- Verify the transaction - check orders and order_items
SELECT * FROM orders WHERE customer_id = 3;
SELECT o.order_id, o.total_amount, o.status, 
       oi.product_id, p.product_name, oi.quantity, oi.price_per_unit
FROM orders o
JOIN order_items oi ON o.order_id = oi.order_id
JOIN products p ON oi.product_id = p.product_id
WHERE o.customer_id = 3;

-- Check product stock levels after transaction
SELECT product_id, product_name, stock_quantity 
FROM products 
WHERE product_id IN (7, 8);